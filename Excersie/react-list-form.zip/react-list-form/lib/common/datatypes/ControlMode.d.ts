/**
 * Determines the display mode of the given control or form.
 */
export declare enum ControlMode {
    Display = 1,
    Edit = 2,
    New = 3
}
//# sourceMappingURL=ControlMode.d.ts.map