export interface IFieldConfiguration {
    key: string;
    fieldName: string;
}
//# sourceMappingURL=IFieldConfiguration.d.ts.map