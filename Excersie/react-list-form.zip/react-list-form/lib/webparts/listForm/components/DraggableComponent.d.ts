import * as React from 'react';
export interface IDraggableComponentProps {
    index: number;
    itemKey: string;
    isDragging?: boolean;
    connectDragSource?(child: any): any;
    connectDropTarget?(child: any): any;
    moveField(fieldKey: string, toIndex: number): void;
    removeField(index: number): void;
}
export default class DraggableComponent extends React.Component<IDraggableComponentProps> {
    constructor(props: any);
    render(): any;
}
//# sourceMappingURL=DraggableComponent.d.ts.map