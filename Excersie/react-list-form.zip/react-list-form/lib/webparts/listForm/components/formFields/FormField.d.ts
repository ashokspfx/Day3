import * as React from 'react';
import { ControlMode } from '../../../../common/datatypes/ControlMode';
export interface IFormFieldProps {
    className?: string;
    controlMode: ControlMode;
    label?: string;
    description?: string;
    required?: boolean;
    disabled?: boolean;
    active?: boolean;
    value: any;
    errorMessage?: string;
    valueChanged(newValue: any): void;
}
declare const FormField: React.SFC<IFormFieldProps>;
export default FormField;
//# sourceMappingURL=FormField.d.ts.map