import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldLookupDisplay: React.SFC<ISPFormFieldProps>;
export default SPFieldLookupDisplay;
//# sourceMappingURL=SPFieldLookupDisplay.d.ts.map