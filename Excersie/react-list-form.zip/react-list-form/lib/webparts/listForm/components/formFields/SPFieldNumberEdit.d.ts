import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldNumberEdit: React.SFC<ISPFormFieldProps>;
export default SPFieldNumberEdit;
//# sourceMappingURL=SPFieldNumberEdit.d.ts.map