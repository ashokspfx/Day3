import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldUserDisplay: React.SFC<ISPFormFieldProps>;
export default SPFieldUserDisplay;
//# sourceMappingURL=SPFieldUserDisplay.d.ts.map