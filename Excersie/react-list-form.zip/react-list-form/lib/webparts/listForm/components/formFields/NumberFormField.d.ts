import * as React from 'react';
import { ITextFieldProps } from 'office-ui-fabric-react/lib/TextField';
export interface INumberFormFieldProps extends ITextFieldProps {
    label?: string;
    locale?: string;
    value: string;
    valueChanged(newValue: string): void;
}
export default class NumberFormField extends React.Component<INumberFormFieldProps, null> {
    constructor(props: any);
    render(): JSX.Element;
    private _validateNumber;
    private parseNumber;
}
//# sourceMappingURL=NumberFormField.d.ts.map