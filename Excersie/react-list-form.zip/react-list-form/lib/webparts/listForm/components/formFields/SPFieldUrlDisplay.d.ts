import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldUrlDisplay: React.SFC<ISPFormFieldProps>;
export default SPFieldUrlDisplay;
//# sourceMappingURL=SPFieldUrlDisplay.d.ts.map