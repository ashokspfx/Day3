import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldLookupEdit: React.SFC<ISPFormFieldProps>;
export default SPFieldLookupEdit;
//# sourceMappingURL=SPFieldLookupEdit.d.ts.map