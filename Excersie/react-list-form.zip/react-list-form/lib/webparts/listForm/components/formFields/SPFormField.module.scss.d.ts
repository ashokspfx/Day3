declare const styles: {
    dropDownFormField: string;
    dateFormField: string;
    unsupportedFieldMessage: string;
};
export default styles;
//# sourceMappingURL=SPFormField.module.scss.d.ts.map