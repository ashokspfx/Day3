import * as React from 'react';
import { IDatePickerProps } from 'office-ui-fabric-react/lib/DatePicker';
export interface IDateFormFieldProps extends IDatePickerProps {
    locale: string;
}
export default class DateFormField extends React.Component<IDateFormFieldProps> {
    constructor(props: any);
    render(): JSX.Element;
}
//# sourceMappingURL=DateFormField.d.ts.map