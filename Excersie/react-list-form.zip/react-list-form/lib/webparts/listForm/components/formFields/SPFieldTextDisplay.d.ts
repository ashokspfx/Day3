import * as React from 'react';
import { ISPFormFieldProps } from './SPFormField';
declare const SPFieldTextDisplay: React.SFC<ISPFormFieldProps>;
export default SPFieldTextDisplay;
//# sourceMappingURL=SPFieldTextDisplay.d.ts.map