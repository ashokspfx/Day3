import { IListFormProps } from './IListFormProps';
declare const _default: __ReactDnd.ContextComponentClass<IListFormProps>;
export default _default;
//# sourceMappingURL=ListForm.d.ts.map