define([], function () {
  return {
    ErrorWebAccessDenied: "'{0}' önceden yapılandırılmış web url'ne erişiminiz yok. Web bölümü özelliklerini olduğu gibi bırakın veya başka bir web url seçin.",
    ErrorWebNotFound: "Önceden yapılandırılmış web url '{0}' artık bulunamadı. Web bölümü özelliklerini olduğu gibi bırakın veya başka bir web url seçin.",
  }
});