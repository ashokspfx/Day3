/* tslint:disable */
require("./ListForm.module.css");
const styles = {
  listForm: 'listForm_e2d8b707',
  title: 'title_e2d8b707',
  description: 'description_e2d8b707',
  formFieldsContainer: 'formFieldsContainer_e2d8b707',
  isDataLoading: 'isDataLoading_e2d8b707',
  formButtonsContainer: 'formButtonsContainer_e2d8b707',
  addFieldToolbox: 'addFieldToolbox_e2d8b707',
  addFieldToolboxPlusButton: 'addFieldToolboxPlusButton_e2d8b707'
};

export default styles;
/* tslint:enable */