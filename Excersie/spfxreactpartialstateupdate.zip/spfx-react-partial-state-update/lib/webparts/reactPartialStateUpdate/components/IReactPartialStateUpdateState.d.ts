export interface IReactPartialStateUpdateState {
    currentDate: Date;
    randomNumber: number;
    ramdomText: string;
}
