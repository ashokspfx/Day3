/// <reference types="react" />
import * as React from 'react';
import { IReactPartialStateUpdateProps } from './IReactPartialStateUpdateProps';
import { IReactPartialStateUpdateState } from './IReactPartialStateUpdateState';
export default class ReactPartialStateUpdate extends React.Component<IReactPartialStateUpdateProps, IReactPartialStateUpdateState> {
    constructor(props: IReactPartialStateUpdateProps, state: IReactPartialStateUpdateState);
    render(): React.ReactElement<IReactPartialStateUpdateProps>;
    private clickShowDate();
    private clickShowRandomNumber();
    private clickShowRandomString();
}
