export interface IReactPartialStateUpdateProps {
  description: string;
}
