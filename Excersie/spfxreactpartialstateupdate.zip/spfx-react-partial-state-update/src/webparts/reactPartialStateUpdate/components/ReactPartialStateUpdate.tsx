import * as React from 'react';
import styles from './ReactPartialStateUpdate.module.scss';
import { IReactPartialStateUpdateProps } from './IReactPartialStateUpdateProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { IReactPartialStateUpdateState } from './IReactPartialStateUpdateState';

export default class ReactPartialStateUpdate extends React.Component<IReactPartialStateUpdateProps, IReactPartialStateUpdateState> {

  public constructor(props: IReactPartialStateUpdateProps, state: IReactPartialStateUpdateState) {
    super(props);

    this.state = {
      currentDate: new Date(),
      randomNumber: 0,
      ramdomText: ""
    };
  }

  public render(): React.ReactElement<IReactPartialStateUpdateProps> {
    return (
      <div className={styles.reactPartialStateUpdate}>
        <div className={styles.container}>
          <div className={styles.row}>
            <div className={styles.column}>
              <span className={styles.title}>Welcome to SharePoint!</span>
              <p className={styles.subTitle}>Customize SharePoint experiences using Web Parts.</p>
              <p className={styles.description}>{escape(this.props.description)}</p>

              <div>
                <a href="#" className={`${styles.button}`} onClick={() => this.clickShowDate()}>
                  <span className={styles.label}>Show Date</span>
                </a>
                &nbsp;
                Current Date: {this.state.currentDate.toDateString()}
              </div>
              <p></p>

              <div>
                <a href="#" className={`${styles.button}`} onClick={() => this.clickShowRandomNumber()}>
                  <span className={styles.label}>Generate Random Number</span>
                </a>
                &nbsp;
                Random Number: {this.state.randomNumber}
              </div>
              <p></p>

              <div>
                <a href="#" className={`${styles.button}`} onClick={() => this.clickShowRandomString()}>
                  <span className={styles.label}>Generate Random String</span>
                </a>
                &nbsp;
                Random Text: {this.state.ramdomText}
              </div>

            </div>
          </div>
        </div>
      </div>
    );
  }

  private clickShowDate(): void {
    this.setState(() => {
      return {
        ...this.state,
        currentDate: new Date()
      };
    });
  }

  private clickShowRandomNumber(): void {
    this.setState(() => {
      return {
        ...this.state,
        randomNumber: Math.floor(Math.random() * 10) + 1
      };
    });
  }

  private clickShowRandomString(): void {
    this.setState(() => {
      return {
        ...this.state,
        ramdomText: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
      };
    });
  }
}
