/* tslint:disable */
require("./ReactPartialStateUpdate.module.css");
const styles = {
  reactPartialStateUpdate: 'reactPartialStateUpdate_51fd45ff',
  container: 'container_51fd45ff',
  row: 'row_51fd45ff',
  column: 'column_51fd45ff',
  'ms-Grid': 'ms-Grid_51fd45ff',
  title: 'title_51fd45ff',
  subTitle: 'subTitle_51fd45ff',
  description: 'description_51fd45ff',
  button: 'button_51fd45ff',
  label: 'label_51fd45ff',
};

export default styles;
/* tslint:enable */