declare interface IReactPartialStateUpdateWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ReactPartialStateUpdateWebPartStrings' {
  const strings: IReactPartialStateUpdateWebPartStrings;
  export = strings;
}
