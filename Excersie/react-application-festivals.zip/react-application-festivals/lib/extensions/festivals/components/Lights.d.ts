import * as React from "react";
export default class Lights extends React.Component<any> {
    render(): React.ReactElement<any>;
}
