import * as React from "react";
export default class Diwali extends React.Component<any> {
    render(): React.ReactElement<any>;
}
