import * as React from "react";
export default class SantaWalking extends React.Component<any> {
    render(): React.ReactElement<any>;
}
