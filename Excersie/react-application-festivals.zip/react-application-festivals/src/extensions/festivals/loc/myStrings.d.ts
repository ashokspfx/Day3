declare interface IFestivalsApplicationCustomizerStrings {
  Title: string;
}

declare module 'FestivalsApplicationCustomizerStrings' {
  const strings: IFestivalsApplicationCustomizerStrings;
  export = strings;
}
