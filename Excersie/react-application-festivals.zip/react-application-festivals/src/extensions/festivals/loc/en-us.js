define([], function() {
  return {
    "Title": "FestivalsApplicationCustomizer"
  }
});