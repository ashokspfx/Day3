/* tslint:disable */
require('./festivals.module.css');
const styles = {
  lightrope: 'lightrope_4a461a7b',
  'flash-1': 'flash-1_4a461a7b',
  'flash-2': 'flash-2_4a461a7b',
  'flash-3': 'flash-3_4a461a7b',
  text: 'text_4a461a7b',
  'text-animation': 'text-animation_4a461a7b',
  bombrocket: 'bombrocket_4a461a7b',
  normalrocket: 'normalrocket_4a461a7b',
  'bombrocket-animate-2': 'bombrocket-animate-2_4a461a7b',
  'normalrocket-animate-2': 'normalrocket-animate-2_4a461a7b',
  'bombrocket-animate-3': 'bombrocket-animate-3_4a461a7b',
  'normalrocket-animate-3': 'normalrocket-animate-3_4a461a7b',
  'bombrocket-animate-1': 'bombrocket-animate-1_4a461a7b',
  'normalrocket-animate-1': 'normalrocket-animate-1_4a461a7b',
  clouds: 'clouds_4a461a7b',
  santa: 'santa_4a461a7b',
  'santa-run': 'santa-run_4a461a7b',
  ground: 'ground_4a461a7b',
  tree: 'tree_4a461a7b',
  'move-tree': 'move-tree_4a461a7b',
  treelarge: 'treelarge_4a461a7b',
  treebackground: 'treebackground_4a461a7b',
  'move-background': 'move-background_4a461a7b',
  caption: 'caption_4a461a7b',
  'caption--small': 'caption--small_4a461a7b',
};

export default styles;
/* tslint:enable */