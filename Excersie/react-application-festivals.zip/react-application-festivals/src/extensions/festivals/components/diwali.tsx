import * as React from "react";
import * as ReactDOM from "react-dom";
import styles from "./festivals.module.scss";

export default class Diwali extends React.Component<any>{

    public render(): React.ReactElement<any> {
        return (
            <div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.bombrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.normalrocket}></div>
                <div className={styles.text}>Happy Diwali</div>
            </div>
        )
    }
}